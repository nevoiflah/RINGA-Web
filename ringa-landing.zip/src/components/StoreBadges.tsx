import type { ReactNode } from "react";
import { useLang } from "../i18n/LanguageContext";
import { AppleIcon, GooglePlayIcon } from "./icons";

type BadgeProps = {
  sub: string;
  name: string;
  icon: ReactNode;
  label: string;
};

/** Static, non-clickable store badge — the apps aren't released yet. */
function Badge({ sub, name, icon, label }: BadgeProps) {
  return (
    <div
      role="img"
      aria-label={label}
      className="inline-flex cursor-default select-none items-center gap-3 rounded-2xl px-5 py-3.5 text-ink"
      style={{ background: "rgba(255,255,255,0.05)", backdropFilter: "blur(8px)" }}
    >
      <span className="flex h-6 w-6 shrink-0 items-center justify-center text-ink">
        {icon}
      </span>
      <span className="flex flex-col text-start leading-tight">
        <span className="text-[0.68rem] font-medium text-muted">{sub}</span>
        <span className="text-[0.95rem] font-extrabold">{name}</span>
      </span>
    </div>
  );
}

export default function StoreBadges({ className = "" }: { className?: string }) {
  const { t } = useLang();
  return (
    <div className={`flex flex-col items-center gap-4 ${className}`}>
      {/* coming-soon status pill */}
      <span className="inline-flex items-center gap-2 rounded-full bg-coral/15 px-4 py-1.5 text-[0.78rem] font-bold tracking-wide text-coral">
        <span
          className="h-1.5 w-1.5 rounded-full bg-coral"
          style={{ animation: "blink 2s ease-in-out infinite" }}
        />
        {t.badges.comingSoon}
      </span>

      <div className="flex flex-wrap items-center justify-center gap-3.5">
        <Badge
          sub={t.badges.appStoreSub}
          name={t.badges.appStoreName}
          icon={<AppleIcon className="h-6 w-6" />}
          label={`${t.badges.appStoreName} — ${t.badges.comingSoon}`}
        />
        <Badge
          sub={t.badges.playSub}
          name={t.badges.playName}
          icon={<GooglePlayIcon className="h-6 w-6" />}
          label={`${t.badges.playName} — ${t.badges.comingSoon}`}
        />
      </div>
    </div>
  );
}
