import type { ReactNode } from "react";
import { H2, LegalLayout, P, Strong, UL } from "../components/LegalPage";
import { useLang } from "../i18n/LanguageContext";
import type { Lang } from "../i18n/translations";

const CONTACT = "shalevdabush@gmail.com";

const Mail = () => (
  <a href={`mailto:${CONTACT}`} className="text-purple hover:text-coral">
    {CONTACT}
  </a>
);

const CONTENT: Record<Lang, { title: string; subtitle: string; body: ReactNode }> = {
  he: {
    title: "מדיניות פרטיות",
    subtitle: "עדכון אחרון: מאי 2025",
    body: (
      <>
        <P>
          RINGA ("האפליקציה", "אנחנו") מחויבת להגנה על פרטיותך. מדיניות זו מסבירה אילו מידע אנו
          אוספים, כיצד אנו משתמשים בו, ומהן זכויותיך.
        </P>

        <H2>1. מידע שאנו אוספים</H2>
        <UL>
          <li>
            <Strong>פרטי חשבון:</Strong> שם, כתובת אימייל, סיסמה מוצפנת.
          </li>
          <li>
            <Strong>מידע פרופיל:</Strong> תמונות, גיל, מגדר, העדפות.
          </li>
          <li>
            <Strong>מיקום מדויק:</Strong> GPS בזמן אמת לאיתור משתמשים בקרבה. המיקום המדויק שלך
            לעולם אינו נחשף למשתמשים אחרים, רק המרחק המשוער.
          </li>
          <li>
            <Strong>הודעות:</Strong> תוכן השיחות בין המשתמשים.
          </li>
          <li>
            <Strong>מזהה משתמש:</Strong> מזהה ייחודי לניהול חשבונך.
          </li>
        </UL>

        <H2>2. כיצד אנו משתמשים במידע</H2>
        <UL>
          <li>הפעלת המכ"ם והצגת משתמשים בקרבה.</li>
          <li>אפשרות להעברת הודעות בין משתמשים.</li>
          <li>שיפור האפליקציה ומניעת שימוש לרעה.</li>
          <li>שליחת הודעות מערכת כמו אימות אימייל ואיפוס סיסמה.</li>
        </UL>

        <H2>3. שיתוף מידע</H2>
        <P>
          אנחנו לא מוכרים, משכירים או משתפים את הנתונים שלך עם צדדים שלישיים לצרכי פרסום. המידע
          שלך מאוחסן בשרתים מאובטחים ומשמש אך ורק להפעלת השירות.
        </P>

        <H2>4. אחסון ואבטחה</H2>
        <P>
          הנתונים שלך מאוחסנים בשרתי ענן מאובטחים. תמונות מאוחסנות ב-Google Cloud Storage. כל
          התקשורת מוצפנת באמצעות HTTPS.
        </P>

        <H2>5. Ghost Mode ואזורי Ghost Zone</H2>
        <P>
          כאשר מצב Ghost Mode פעיל, המיקום שלך אינו נשלח לשרת ואינך מופיע בתוצאות החיפוש של
          משתמשים אחרים. Ghost Zones מאפשרים לך להגדיר אזורים קבועים שבהם אתה תמיד בלתי נראה.
        </P>

        <H2>6. מחיקת נתונים</H2>
        <P>
          תוכל למחוק את חשבונך בכל עת דרך הגדרות האפליקציה. מחיקת החשבון תגרום למחיקה בלתי הפיכה
          של כל הנתונים שלך ממערכותינו.
        </P>

        <H2>7. גיל מינימלי</H2>
        <P>
          האפליקציה מיועדת למשתמשים בני 18 ומעלה. איננו אוספים ביודעין מידע ממשתמשים מתחת לגיל
          18.
        </P>

        <H2>8. צור קשר</H2>
        <P>
          לשאלות בנושא פרטיות: <Mail />
        </P>
      </>
    ),
  },

  en: {
    title: "Privacy Policy",
    subtitle: "Last updated: May 2025",
    body: (
      <>
        <P>
          RINGA ("the App", "we") is committed to protecting your privacy. This policy explains
          what information we collect, how we use it, and what your rights are.
        </P>

        <H2>1. Information We Collect</H2>
        <UL>
          <li>
            <Strong>Account details:</Strong> name, email address, encrypted password.
          </li>
          <li>
            <Strong>Profile information:</Strong> photos, age, gender, preferences.
          </li>
          <li>
            <Strong>Precise location:</Strong> real-time GPS to find nearby users. Your exact
            location is never revealed to other users — only the approximate distance.
          </li>
          <li>
            <Strong>Messages:</Strong> the content of conversations between users.
          </li>
          <li>
            <Strong>User ID:</Strong> a unique identifier for managing your account.
          </li>
        </UL>

        <H2>2. How We Use Information</H2>
        <UL>
          <li>Operating the radar and showing nearby users.</li>
          <li>Enabling messaging between users.</li>
          <li>Improving the App and preventing abuse.</li>
          <li>Sending system messages such as email verification and password reset.</li>
        </UL>

        <H2>3. Sharing Information</H2>
        <P>
          We do not sell, rent or share your data with third parties for advertising purposes.
          Your information is stored on secure servers and used solely to operate the service.
        </P>

        <H2>4. Storage and Security</H2>
        <P>
          Your data is stored on secure cloud servers. Photos are stored in Google Cloud
          Storage. All communication is encrypted via HTTPS.
        </P>

        <H2>5. Ghost Mode and Ghost Zones</H2>
        <P>
          When Ghost Mode is active, your location is not sent to the server and you do not
          appear in other users' search results. Ghost Zones let you define permanent areas
          where you are always invisible.
        </P>

        <H2>6. Data Deletion</H2>
        <P>
          You may delete your account at any time through the App settings. Deleting your
          account will irreversibly delete all of your data from our systems.
        </P>

        <H2>7. Minimum Age</H2>
        <P>
          The App is intended for users aged 18 and over. We do not knowingly collect
          information from users under 18.
        </P>

        <H2>8. Contact</H2>
        <P>
          For privacy questions: <Mail />
        </P>
      </>
    ),
  },
};

export default function Privacy() {
  const { lang } = useLang();
  const c = CONTENT[lang];
  return (
    <LegalLayout title={c.title} subtitle={c.subtitle}>
      {c.body}
    </LegalLayout>
  );
}
