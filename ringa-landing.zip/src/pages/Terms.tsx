import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import { H2, LegalLayout, P, Strong, UL } from "../components/LegalPage";
import { useLang } from "../i18n/LanguageContext";
import type { Lang } from "../i18n/translations";

const CONTACT = "ringatestuser@gmail.com";

const Mail = () => (
  <a href={`mailto:${CONTACT}`} className="text-purple hover:text-coral">
    {CONTACT}
  </a>
);

const CONTENT: Record<Lang, { title: string; subtitle: string; body: ReactNode }> = {
  he: {
    title: "תנאי שימוש",
    subtitle: "עדכון אחרון: מאי 2025",
    body: (
      <>
        <P>
          ברוכים הבאים ל-RINGA ("האפליקציה", "אנחנו", "שלנו"). השימוש באפליקציה מהווה הסכמה
          לתנאים הבאים. אנא קרא אותם בעיון לפני השימוש.
        </P>

        <H2>1. כשירות לשימוש</H2>
        <P>
          השימוש באפליקציה מותר רק למשתמשים בני <Strong>18 ומעלה</Strong>. על ידי יצירת חשבון
          אתה מאשר כי הינך בגיר לפי חוק המדינה בה אתה מתגורר.
        </P>

        <H2>2. חשבון משתמש</H2>
        <UL>
          <li>עליך לספק פרטים מדויקים ועדכניים בעת ההרשמה.</li>
          <li>אתה אחראי לשמירה על סודיות פרטי הכניסה לחשבונך.</li>
          <li>אין להעביר את חשבונך לאחר.</li>
          <li>אנו שומרים לעצמנו את הזכות להשעות או לסגור חשבון שמפר את התנאים.</li>
        </UL>

        <H2>3. התנהגות מותרת ואסורה</H2>
        <P>
          השימוש באפליקציה מחייב התנהגות מכבדת כלפי משתמשים אחרים.{" "}
          <Strong>אסור בהחלט:</Strong>
        </P>
        <UL>
          <li>שליחת תוכן פוגעני, מיני, מאיים, גזעני או מטריד.</li>
          <li>התחזות לאדם אחר או יצירת פרופיל מזויף.</li>
          <li>שימוש באפליקציה למטרות מסחריות ללא אישור מפורש.</li>
          <li>ניסיון לגשת לנתונים של משתמשים אחרים ללא רשותם.</li>
          <li>פרסום פרטים אישיים של אנשים אחרים ("דוקסינג").</li>
          <li>שימוש בכלים אוטומטיים, בוטים, או סקריפטים לגישה לאפליקציה.</li>
        </UL>

        <H2>4. תוכן משתמשים</H2>
        <P>
          כל תוכן שאתה מעלה לאפליקציה (תמונות, הודעות, פרטי פרופיל) נשאר בבעלותך. עם זאת, אתה
          מעניק לנו רישיון מוגבל לאחסן ולהציג אותו לשם הפעלת השירות.
        </P>
        <P>אנו שומרים לעצמנו את הזכות להסיר תוכן שמפר את תנאי השימוש ללא הודעה מוקדמת.</P>

        <H2>5. פרטיות ומיקום</H2>
        <P>
          האפליקציה משתמשת ב-GPS לאיתור משתמשים בקרבה. המיקום המדויק שלך{" "}
          <Strong>לעולם אינו נחשף</Strong> למשתמשים אחרים — רק מרחק משוער. לפרטים נוספים ראה את{" "}
          <Link to="/privacy" className="text-purple hover:text-coral">
            מדיניות הפרטיות
          </Link>{" "}
          שלנו.
        </P>

        <H2>6. Ghost Mode ואזורי Ghost</H2>
        <P>
          מצב Ghost Mode ואזורי Ghost Zone הם כלים לשמירה על הפרטיות שלך. השימוש בהם הוא
          באחריותך. אנחנו לא נשאים באחריות אם נתוני מיקום הועברו לפני הפעלת המצב.
        </P>

        <H2>7. הגבלת אחריות</H2>
        <P>
          RINGA מסופקת "כמות שהיא" ללא אחריות מפורשת. אנחנו לא נשאים באחריות לנזקים הנובעים
          מפגישות בין משתמשים, שיחות, או שימוש לרעה בפלטפורמה על ידי צדדים שלישיים.
        </P>

        <H2>8. שינויים בשירות</H2>
        <P>
          אנו רשאים לשנות, להשעות, או להפסיק חלקים מהשירות בכל עת, עם הודעה סבירה או בלעדיה,
          בהתאם לשיקול דעתנו.
        </P>

        <H2>9. שינויים בתנאים</H2>
        <P>
          אנו עשויים לעדכן תנאים אלה מעת לעת. במקרה של שינוי מהותי, נודיע לך דרך האפליקציה. המשך
          השימוש לאחר השינוי מהווה הסכמה לתנאים המעודכנים.
        </P>

        <H2>10. סיום חשבון</H2>
        <P>
          תוכל למחוק את חשבונך בכל עת דרך הגדרות האפליקציה. מחיקת החשבון תגרום למחיקה בלתי הפיכה
          של כל הנתונים שלך.
        </P>

        <H2>11. יצירת קשר</H2>
        <P>
          לכל שאלה בנוגע לתנאי השימוש: <Mail />
        </P>
      </>
    ),
  },

  en: {
    title: "Terms of Use",
    subtitle: "Last updated: May 2025",
    body: (
      <>
        <P>
          Welcome to RINGA ("the App", "we", "us", "our"). By using the App you agree to the
          following terms. Please read them carefully before using the App.
        </P>

        <H2>1. Eligibility</H2>
        <P>
          The App may be used only by people aged <Strong>18 and over</Strong>. By creating an
          account you confirm that you are of legal age in the country where you reside.
        </P>

        <H2>2. Your Account</H2>
        <UL>
          <li>You must provide accurate, up-to-date information when registering.</li>
          <li>You are responsible for keeping your login credentials confidential.</li>
          <li>You may not transfer your account to anyone else.</li>
          <li>
            We reserve the right to suspend or close any account that violates these terms.
          </li>
        </UL>

        <H2>3. Permitted and Prohibited Conduct</H2>
        <P>
          Using the App requires respectful behavior toward other users.{" "}
          <Strong>The following is strictly prohibited:</Strong>
        </P>
        <UL>
          <li>Sending offensive, sexual, threatening, racist or harassing content.</li>
          <li>Impersonating another person or creating a fake profile.</li>
          <li>Using the App for commercial purposes without explicit permission.</li>
          <li>Attempting to access other users' data without their permission.</li>
          <li>Publishing other people's personal details ("doxxing").</li>
          <li>Using automated tools, bots or scripts to access the App.</li>
        </UL>

        <H2>4. User Content</H2>
        <P>
          Any content you upload to the App (photos, messages, profile details) remains yours.
          However, you grant us a limited license to store and display it in order to operate
          the service.
        </P>
        <P>
          We reserve the right to remove content that violates these terms without prior
          notice.
        </P>

        <H2>5. Privacy and Location</H2>
        <P>
          The App uses GPS to find nearby users. Your exact location is{" "}
          <Strong>never revealed</Strong> to other users — only an approximate distance. For
          more details see our{" "}
          <Link to="/privacy" className="text-purple hover:text-coral">
            Privacy Policy
          </Link>
          .
        </P>

        <H2>6. Ghost Mode and Ghost Zones</H2>
        <P>
          Ghost Mode and Ghost Zones are tools to protect your privacy. Using them is at your
          own responsibility. We are not liable if location data was transmitted before the
          mode was activated.
        </P>

        <H2>7. Limitation of Liability</H2>
        <P>
          RINGA is provided "as is" without any express warranty. We are not liable for damages
          arising from meetings between users, conversations, or misuse of the platform by
          third parties.
        </P>

        <H2>8. Changes to the Service</H2>
        <P>
          We may change, suspend, or discontinue parts of the service at any time, with or
          without reasonable notice, at our discretion.
        </P>

        <H2>9. Changes to These Terms</H2>
        <P>
          We may update these terms from time to time. In the event of a material change, we
          will notify you through the App. Continued use after the change constitutes acceptance
          of the updated terms.
        </P>

        <H2>10. Account Termination</H2>
        <P>
          You may delete your account at any time through the App settings. Deleting your
          account will irreversibly delete all of your data.
        </P>

        <H2>11. Contact</H2>
        <P>
          For any question regarding these Terms of Use: <Mail />
        </P>
      </>
    ),
  },
};

export default function Terms() {
  const { lang } = useLang();
  const c = CONTENT[lang];
  return (
    <LegalLayout title={c.title} subtitle={c.subtitle}>
      {c.body}
    </LegalLayout>
  );
}
